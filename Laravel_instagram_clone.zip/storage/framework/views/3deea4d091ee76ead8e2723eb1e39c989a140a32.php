<?php $__env->startComponent('mail::message'); ?>
# Welcome to Shahriar Project

Have fun exploring it

<img src="https://img.pngio.com/have-fun-transparent-png-clipart-free-download-ya-webdesign-have-fun-png-320_316.png" alt="Have Fun Image">

Thanks,<br>
Shahriar
<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\Laravel\Laravel_instagram_clone\resources\views/emails/welcome-email.blade.php ENDPATH**/ ?>