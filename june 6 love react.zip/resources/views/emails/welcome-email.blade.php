@component('mail::message')
# Welcome to Shahriar Project

Have fun exploring it

<img src="https://img.pngio.com/have-fun-transparent-png-clipart-free-download-ya-webdesign-have-fun-png-320_316.png" alt="Have Fun Image">

Thanks,<br>
Shahriar
@endcomponent
