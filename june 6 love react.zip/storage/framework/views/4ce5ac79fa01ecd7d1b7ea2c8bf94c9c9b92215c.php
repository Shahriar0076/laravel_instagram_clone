<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-3"><img src="https://image.freepik.com/free-vector/instagram-logo_1045-436.jpg" alt="" style="max-height: 220px;" class="rounded-circle"></div>
        <div class="col-9">
            <div class="d-flex justify-content-between align-items-baseline">
                <h1><?php echo e($user->username); ?></h1>
                <a href="#">Add new post </a>
            </div>
            <div class="d-flex">
                <div class="pr-5"><strong>153</strong> posts</div>
                <div class="pr-5"><strong>23k</strong> followers</div>
                <div class="pr-5"><strong>212</strong> following</div>
            </div>
            <div class="pt-4"><strong><?php echo e($user->profile->title); ?></strong></div>
            <div class=""><?php echo e($user->profile->description); ?></div>
            <div class=""><strong><a href="#"><?php echo e($user->profile->url ?? 'N/A'); ?></a></strong></div>

        </div>
        
    </div>

    <div class="row">
        <div class="col-4"><img src="https://image.freepik.com/free-photo/instagram-logo-3d-rendering-close-up-account-promotion-template_1379-4793.jpg" alt="" class="w-100 pt-5"></div>
        <div class="col-4"><img src="https://image.freepik.com/free-photo/instagram-logo-3d-rendering-close-up-account-promotion-template_1379-4793.jpg" alt="" class="w-100 pt-5"></div>
        <div class="col-4"><img src="https://image.freepik.com/free-photo/instagram-logo-3d-rendering-close-up-account-promotion-template_1379-4793.jpg" alt="" class="w-100 pt-5"></div>
        <div class="col-4"><img src="https://image.freepik.com/free-photo/instagram-logo-3d-rendering-close-up-account-promotion-template_1379-4793.jpg" alt="" class="w-100 pt-5"></div>
        <div class="col-4"><img src="https://image.freepik.com/free-photo/instagram-logo-3d-rendering-close-up-account-promotion-template_1379-4793.jpg" alt="" class="w-100 pt-5"></div>
        <div class="col-4"><img src="https://image.freepik.com/free-photo/instagram-logo-3d-rendering-close-up-account-promotion-template_1379-4793.jpg" alt="" class="w-100 pt-5"></div>
        
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\Laravel_instagram_clone\resources\views/home.blade.php ENDPATH**/ ?>