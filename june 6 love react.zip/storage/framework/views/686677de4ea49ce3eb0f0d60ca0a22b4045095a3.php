

<?php $__env->startSection('content'); ?>

<div class="container">
    <?php $__currentLoopData = $userList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="row mt-5">        
        <div class="col-3"><a href="/profile/<?php echo e($list->id); ?>"><img src="<?php echo e($list->profile->profileImage()); ?>" alt="" class="w-50"></a></div>
        <div class="col-7"><a class="text-decoration-none" href="/profile/<?php echo e($list->id); ?>"><h5><?php echo e($list->username); ?></h5></a></div>
        <div class="col-2"><follow-button user-id="<?php echo e($list->id); ?>" follows="<?php echo e((auth()->user()) ? auth()->user()->following->contains($list->id) : false); ?>"></follow-button></div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Instagram clone\Laravel_instagram_clone\resources\views/findPeople.blade.php ENDPATH**/ ?>