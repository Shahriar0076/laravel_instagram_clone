

<?php $__env->startSection('content'); ?>
<div class="container"> 
    
    
    <?php if(count($posts) > 0): ?>
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           
            <div class="row">
                <div class="col-6 offset-3">
                    <a href="/profile/<?php echo e($post->user->id); ?>" ><img src="/storage/<?php echo e($post->image); ?>" alt="" class="w-100"></a>
                </div>
            </div>
            <div class="row pt-2 pb-4">
                
                <div class="col-6 offset-3"> 
                    
                    <?php if($post->reacts->where('user_id',auth()->user()->id)->count()> 0): ?>
                        <div style="display: flex;">
                            <i class="fa fa-heart pulse redheart" onclick="sendlove(this)" name="<?php echo e($post->id); ?>"></i>
                            <p class="reactcounts" style="  margin-left: 8px;  margin-top: 2px;  "><?php echo e($post->reacts->count()); ?> </p>
                            
                        </div>         
                    <?php else: ?>
                        <div style="display: flex;">
                            <i class="fa fa-heart pulse" onclick="sendlove(this)" name="<?php echo e($post->id); ?>"></i>
                            <p class="reactcounts" style="  margin-left: 8px;  margin-top: 2px;  "><?php echo e($post->reacts->count()); ?> </p> 
                            
                            
                        </div>         
                    <?php endif; ?>
                        
                        <p>
                            <span class="font-weight-bold">
                                <a href="/profile/<?php echo e($post->user->id); ?>">
                                    <span class="text-dark"><?php echo e($post->user->username); ?></span>
                                </a>
                            </span> <?php echo e($post->caption); ?>

                        </p>
                    </div>
                </div>    
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
    <?php else: ?>
        <h5>Currently you are not following anyone!!</h5>
        <h6><a href="/follow">Click here</a> to follow others</h6>
        <h6><a href="/profile/<?php echo e(Auth::user()->id); ?>">Click here</a> to update your profile</h6>
    <?php endif; ?>

    
        
    
    
    

    

    <div class="row">
        <div class="col-12 d-flex justify-content-center">
            <?php echo e($posts->links()); ?>

        </div>
    </div>
</div>
    

<?php $__env->stopSection(); ?>

<style>
    .fa-heart {
        color: #2d2929;
        font-size: 25px;
        cursor: pointer;
        transition: all 0.2s;
    } 
    .redheart{color: red;}   

</style>
    

<script>
    

    
    
    function sendlove (e){
        //$(e).css("color", "red")
        var postid = $(e).attr('name');     
        //console.log();       
        if($(e).css("color")==='rgb(45, 41, 41)'){             
            $.ajax({   
            url: '/user/<?php echo e(auth()->user()->id); ?>/post/'+postid,
            method:"POST",
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            data: {
                //get_adminImages:true,orderid:id
            },
            success: function(data){
               // $('#result').html(data);
                $(e).css("color", "red");//unloved to loved 
                
                $(e).siblings().html(parseInt($(e).siblings().html())+1);
               console.log('hoho success');                
            }
            });
        }
        else{ 
            $.ajax({   
            url: '/user/<?php echo e(auth()->user()->id); ?>/post/'+postid,
            method:"DELETE",
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            data: {
                //get_adminImages:true,orderid:id
            },
            success: function(data){
               // $('#result').html(data);
               $(e).css("color", "#2d2929");//loved  to unloved
                
                $(e).siblings().html(parseInt($(e).siblings().html())-1);
               console.log('hoho success');                
            }
            });
         }
        

        
        
        

        

    }

</script>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Instagram clone\Laravel_instagram_clone\resources\views/posts/index.blade.php ENDPATH**/ ?>